package com.example.livetranslate

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import kotlin.concurrent.thread

class MainActivity : Activity() {
    companion object {
        const val REQ_OVERLAY = 1
        const val REQ_MIC = 2
        const val REQ_PROJECTION = 3
    }

    private lateinit var status: TextView
    private lateinit var btn: Button
    private var askedMic = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (24 * resources.displayMetrics.density).toInt()
        status = TextView(this).apply {
            textSize = 16f
            text = "اضغط «ابدأ» وسأطلب منك الأذونات خطوة بخطوة. بعدها افتح الريلز وستظهر الترجمة فوقه."
        }
        btn = Button(this).apply { setOnClickListener { onButton() } }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(pad, pad * 2, pad, pad)
            addView(status)
            addView(btn)
        })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() { btn.text = if (TranslateService.running) "إيقاف الترجمة" else "ابدأ الترجمة" }
    private fun say(s: String) = runOnUiThread { status.text = s }

    private fun onButton() {
        if (TranslateService.running) {
            stopService(Intent(this, TranslateService::class.java))
            TranslateService.running = false
            refresh(); say("تم الإيقاف.")
        } else proceed()
    }

    /** Runs the setup steps in order; each step calls proceed() again when it finishes. */
    private fun proceed() {
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        when {
            !Settings.canDrawOverlays(this) -> {
                say("فعّل «العرض فوق التطبيقات» لهذا التطبيق ثم ارجع.")
                startActivityForResult(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), REQ_OVERLAY
                )
            }
            !mic && !askedMic -> {
                askedMic = true
                val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
                if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
                requestPermissions(perms.toTypedArray(), REQ_MIC)
            }
            !mic -> say("فعّل إذن الميكروفون من إعدادات التطبيق (لا يسجل الميكروفون، فقط مطلوب لالتقاط صوت الجهاز).")
            else -> downloadModelsThenCapture()
        }
    }

    private fun downloadModelsThenCapture() {
        btn.isEnabled = false
        thread {
            try {
                if (!Models.voskReady(this)) {
                    var last = -1
                    say("تحميل نموذج التعرف على الكلام... 0%")
                    Models.downloadVosk(this) { p ->
                        if (p != last) { last = p; say("تحميل نموذج التعرف على الكلام... $p%") }
                    }
                }
                runOnUiThread {
                    say("تحميل نموذج الترجمة (إنجليزي ← عربي)...")
                    val t = Models.newTranslator()
                    t.downloadModelIfNeeded(DownloadConditions.Builder().build())
                        .addOnSuccessListener { t.close(); btn.isEnabled = true; askProjection() }
                        .addOnFailureListener { t.close(); btn.isEnabled = true; say("فشل تحميل نموذج الترجمة. تأكد من الإنترنت وحاول مرة ثانية.") }
                }
            } catch (e: Exception) {
                runOnUiThread { btn.isEnabled = true }
                say("فشل التحميل: ${e.message}")
            }
        }
    }

    private fun askProjection() {
        say("اقبل نافذة تسجيل الشاشة. التطبيق يلتقط الصوت فقط ولا يسجل الشاشة.")
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION)
    }

    override fun onRequestPermissionsResult(req: Int, perms: Array<String>, res: IntArray) {
        super.onRequestPermissionsResult(req, perms, res)
        proceed()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        when (req) {
            REQ_OVERLAY -> proceed()
            REQ_PROJECTION ->
                if (res == RESULT_OK && data != null) {
                    startForegroundService(
                        Intent(this, TranslateService::class.java).putExtra("code", res).putExtra("data", data)
                    )
                    TranslateService.running = true
                    refresh()
                    say("اشتغلت! افتح الريلز وستظهر الترجمة فوقه.")
                    moveTaskToBack(true)
                } else say("لم يتم قبول إذن تسجيل الشاشة.")
        }
    }
}
