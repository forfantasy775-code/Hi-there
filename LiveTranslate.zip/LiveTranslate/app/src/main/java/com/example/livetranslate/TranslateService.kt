package com.example.livetranslate

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.nl.translate.Translator
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.util.concurrent.atomic.AtomicInteger

class TranslateService : Service() {
    companion object {
        const val ACTION_STOP = "stop"
        @Volatile var running = false
        private const val RATE = 16000
        private const val CHANNEL = "translate"
    }

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var translator: Translator? = null
    private var box: LinearLayout? = null
    private lateinit var arText: TextView
    private lateinit var enText: TextView
    @Volatile private var active = false
    private val reqId = AtomicInteger()
    private var shownId = 0
    private val hide = Runnable { box?.visibility = View.GONE }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (active) return START_NOT_STICKY
        startInForeground() // must happen before getMediaProjection()
        val code = i?.getIntExtra("code", 0) ?: 0
        val data = i?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { if (active) stopSelf() }
            }, main)
        }
        translator = Models.newTranslator()
        showOverlay()
        active = true
        running = true
        Thread { captureLoop() }.start()
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "الترجمة المباشرة", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, TranslateService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("الترجمة المباشرة تعمل")
            .addAction(android.R.drawable.ic_media_pause, "إيقاف", stop)
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showOverlay() {
        arText = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_RTL
        }
        enText = TextView(this).apply {
            setTextColor(0xB3FFFFFF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            gravity = Gravity.CENTER
        }
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply { setColor(0x80000000.toInt()); cornerRadius = dp(14).toFloat() }
            addView(arText)
            addView(enText)
            visibility = View.GONE
        }
        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.94).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(120) } // change y to move it up/down
        getSystemService(WindowManager::class.java).addView(box, lp)
    }

    private fun tail(s: String) = s.split(" ").takeLast(18).joinToString(" ")

    /** Translate on-device and show; stale (out-of-order) results are dropped. */
    private fun show(en: String) {
        val id = reqId.incrementAndGet()
        translator?.translate(en)?.addOnSuccessListener { ar ->
            if (id < shownId) return@addOnSuccessListener
            shownId = id
            arText.text = ar
            enText.text = en
            box?.visibility = View.VISIBLE
            main.removeCallbacks(hide)
            main.postDelayed(hide, 4500)
        }
    }

    private fun captureLoop() {
        var model: Model? = null
        var rec: Recognizer? = null
        var ar: AudioRecord? = null
        try {
            model = Model(Models.voskDir(this).absolutePath)
            rec = Recognizer(model, RATE.toFloat())
            val cfg = AudioPlaybackCaptureConfiguration.Builder(projection!!)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
            val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            ar = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(maxOf(min, 16384))
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
            ar.startRecording()

            val buf = ShortArray(4000)
            var lastPartial = ""
            var lastTime = 0L
            while (active) {
                val n = ar.read(buf, 0, buf.size)
                if (n < 0) break
                if (n == 0) continue
                if (rec.acceptWaveForm(buf, n)) {
                    val t = JSONObject(rec.result).optString("text")
                    if (t.isNotBlank()) { lastPartial = ""; main.post { show(tail(t)) } }
                } else {
                    val p = JSONObject(rec.partialResult).optString("partial")
                    val now = SystemClock.elapsedRealtime()
                    if (p.length > 3 && p != lastPartial && now - lastTime > 900) {
                        lastPartial = p; lastTime = now
                        main.post { show(tail(p)) }
                    }
                }
            }
        } catch (e: Throwable) {
            main.post { arText.text = "خطأ: ${e.message}"; box?.visibility = View.VISIBLE }
        } finally {
            ar?.let { try { it.stop() } catch (_: Exception) {}; it.release() }
            rec?.close()
            model?.close()
        }
    }

    override fun onDestroy() {
        active = false
        running = false
        main.removeCallbacks(hide)
        box?.let { try { getSystemService(WindowManager::class.java).removeView(it) } catch (_: Exception) {} }
        projection?.stop()
        translator?.close()
        super.onDestroy()
    }
}
