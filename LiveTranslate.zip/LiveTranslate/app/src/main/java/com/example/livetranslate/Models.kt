package com.example.livetranslate

import android.content.Context
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.io.File
import java.net.URL
import java.util.zip.ZipInputStream

object Models {
    private const val VOSK_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    private const val VOSK_FOLDER = "vosk-model-small-en-us-0.15"

    fun voskDir(ctx: Context) = File(ctx.filesDir, "model-en")
    fun voskReady(ctx: Context) = File(voskDir(ctx), "am/final.mdl").exists()

    fun newTranslator(): Translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.ARABIC)
            .build()
    )

    /** Blocking: call from a background thread. Downloads + unzips the offline speech model. */
    fun downloadVosk(ctx: Context, onProgress: (Int) -> Unit) {
        val tmp = File(ctx.filesDir, "model_tmp").apply { deleteRecursively(); mkdirs() }
        val zip = File(ctx.cacheDir, "vosk.zip")
        val conn = URL(VOSK_URL).openConnection().apply { connectTimeout = 15000; readTimeout = 30000 }
        val total = conn.contentLength.toLong()
        conn.getInputStream().use { inp ->
            zip.outputStream().use { out ->
                val buf = ByteArray(65536)
                var done = 0L
                var n: Int
                while (inp.read(buf).also { n = it } > 0) {
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) onProgress((done * 100 / total).toInt())
                }
            }
        }
        ZipInputStream(zip.inputStream()).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                val f = File(tmp, e.name)
                if (!f.canonicalPath.startsWith(tmp.canonicalPath)) throw SecurityException("bad zip entry")
                if (e.isDirectory) f.mkdirs() else {
                    f.parentFile?.mkdirs()
                    f.outputStream().use { zis.copyTo(it) }
                }
                e = zis.nextEntry
            }
        }
        voskDir(ctx).deleteRecursively()
        File(tmp, VOSK_FOLDER).renameTo(voskDir(ctx))
        tmp.deleteRecursively()
        zip.delete()
    }
}
